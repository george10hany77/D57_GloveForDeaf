/*
 * LCD_private.h
 *
 * Created: 9/29/2023 6:54:19 PM
 *  Author: George
 */ 


#ifndef LCD_PRIVATE_H_
#define LCD_PRIVATE_H_

static void private_WriteHalfREG(u8 value);
static u8 u8Size(u8 num);


#endif /* LCD_PRIVATE_H_ */